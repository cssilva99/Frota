<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('auth/login');
});


Auth::routes();


 
Route::get('/parametrizacaoViatura', 'HomeController@index');

Route::post('/parametrizacaoViatura', 'HomeController@create');



Route::get('/vehicle/parametrizacaoViatura', 'HomeController@index')->name('vehicleForm');

Route::post('/vehicle/parametrizacaoViatura', 'HomeController@create')->name('createVehicle');



/*
Route::get('/parametrizacaoViatura',[
	'uses' => 'HomeController@create'
]);

Route::post('/parametrizacaoViatura',[
	'uses' => 'HomeController@store'
]);	
 */

