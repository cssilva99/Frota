<?php $__env->startSection('content'); ?>

<br>
 <h1> Criar Viatura </h1>

<div class="row">
 <div class="col-md-6">

  <form method="post" action="<?php echo e(route('createVehicle')); ?>">
  <?php echo e(csrf_field()); ?>


      <div class="form-group">
	<label> Matricula: </label>
	<input type="text" class="form-control" name="matricula">      
      </div>
	
      <div class=form-group">
         <label>Descrição: </label>
         <textarea name="descricao" class="form-control"></textarea>
      </div>

      <button class="btn btn-primary"> Criar Viatura </button>
  </form> 
    



</br>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>