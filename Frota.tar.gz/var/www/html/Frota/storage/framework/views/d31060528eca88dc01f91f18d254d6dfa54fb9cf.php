<?php $__env->startSection('content'); ?>

<br>
 <h1> Criar Viatura </h1>

<div class="row">
 <div class="col-md-6">

  <form method="post" action="<?php echo e(route('vehicle/parametrizacaoViatura')); ?>">
  <?php echo e(csrf_field()); ?>


      <div class="form-group">
	<label> Matricula: </label>
	<input type="text" class="form-control" name="matricula">      
      </div>
	
      <div class=form-group">
         <label>Descrição: </label>
         <textarea name="descricao" class="form-control"></textarea>
      </div>

      <button class="btn btn-primary"> Criar Viatura </button>
  </form>




<!-- <?php echo e(HTML::ul($errors->all())); ?>


 <?php echo e(Form::open(array('url'=>'parametrizacao'))); ?>


 <div class="form-group">
	<?php echo e(Form::label('nome', 'Name')); ?>

	<?php echo e(Form::text('name', Input::old('name'), array('class' => 'form-control'))); ?>


 </div>

 <div class="form-group">
 	<?php echo e(Form::label('matricula','Email')); ?>

	<?php echo e(Form::email('email', Input::old('email'), array('class' => 'form-controll'))); ?>

 </div>

 <div class="form-group">
	<?php echo e(Form::label('descricao', 'Email')); ?>

	<?php echo e(Form::label('email', Input::old('email'), array('class' => 'form-controll'))); ?>

 </div>

 <div class="form-group">
	<?php echo e(Form::label('nerd_level','Nerd Level')); ?>

        <?php echo e(Form::Select('nerd_level', array('0' => 'Select a Level', '1' => 'Sees SUnlight'))); ?> 
 </div>

 <?php echo e(Form::submit('Create the Nerd!', array('class' => 'btn btn-primary'))); ?>


 <?php echo e(Form::close()); ?>	

-->

</br>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>