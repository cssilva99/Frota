@extends('main')

@section('content')

<br>
 <h1> Criar Viatura </h1>

<div class="row">
 <div class="col-md-6">

  <form method="post" action="{{ route('createVehicle') }}">
  {{ csrf_field() }}

      <div class="form-group">
	<label> Matricula: </label>
	<input type="text" class="form-control" name="matricula">      
      </div>
	
      <div class=form-group">
         <label>Descrição: </label>
         <textarea name="descricao" class="form-control"></textarea>
      </div>

      <button class="btn btn-primary"> Criar Viatura </button>
  </form> 
    



</br>

@stop
