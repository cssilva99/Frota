@extends('main')

@section('content')

<br>
 <h1> Criar Viatura </h1>

<div class="row">
 <div class="col-md-6">

  <form method="post" action="/parametrizacaoViatura">
   <!--
  <form method="post" action="{{ route('parametrizacaoViatura') }}">
   -->
   {{ csrf_field() }}

      <div class="form-group">
	<label> Matricula: </label>
	<input type="text" class="form-control" name="matricula">      
      </div>
	
      <div class=form-group">
         <label>Descrição: </label>
         <textarea name="descricao" class="form-control"></textarea>
      </div>

      <button class="btn btn-primary"> Criar Viatura </button>
  </form>




<!-- {{ HTML::ul($errors->all())}}

 {{Form::open(array('url'=>'parametrizacao'))}}

 <div class="form-group">
	{{Form::label('nome', 'Name')}}
	{{Form::text('name', Input::old('name'), array('class' => 'form-control'))}}

 </div>

 <div class="form-group">
 	{{Form::label('matricula','Email')}}
	{{Form::email('email', Input::old('email'), array('class' => 'form-controll'))}}
 </div>

 <div class="form-group">
	{{Form::label('descricao', 'Email')}}
	{{Form::label('email', Input::old('email'), array('class' => 'form-controll'))}}
 </div>

 <div class="form-group">
	{{Form::label('nerd_level','Nerd Level')}}
        {{Form::Select('nerd_level', array('0' => 'Select a Level', '1' => 'Sees SUnlight'))}} 
 </div>

 {{Form::submit('Create the Nerd!', array('class' => 'btn btn-primary')) }}

 {{Form::close() }}	

-->

</br>

@stop
